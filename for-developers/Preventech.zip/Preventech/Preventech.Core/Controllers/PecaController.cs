using Microsoft.Extensions.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Preventech.Core.Models;
using Preventech.Core.DatabaseContexts;
using Preventech.Core.DTOs;

namespace Preventech.Core.Controllers
{
    [Route("api/estoque")]
    [ApiController]
    public class PecaController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public PecaController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost("cadastro")]
        public async Task<ApiResponse<Peca>> CadastrarPeca([FromBody] Peca peca)
        {
            if (peca == null)
            {
                return new ApiResponse<Peca>
                {
                    Success = false
                    Message = "Dados da peça inválidos",
                    Data = null
                };
            }

            try {
                // Adiciona a peça ao contexto
                _context.Pecas.Add(peca);

                // Salva as mudanças no banco de dados
                await _context.SaveChangesAsync();

                return new ApiResponse<Peca>
                {
                    Success = true,
                    Message  "Peça cadastrada com sucesso",
                    Data = peca
                }
            }
        }
    }
}